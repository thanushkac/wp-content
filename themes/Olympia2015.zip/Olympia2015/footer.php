<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?>
<?php get_sidebar( 'footer' ); ?>



	<div class="footer text-center">
<p class="h6">Copyright (c) Olympia Buildings All Rights Reserved | CALL TO SAVE NOW! 1-888-449-7756</p>
</div>

	

	<?php wp_footer(); ?>
    </div><!-- #main -->
</body>
</html>