<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?>
<div class="container">
<div class="footeritems">
				
		<div class ="hr"></div>
        <p class="text-center small">Pittsburgh Buddhist center is a registered non profit organization. | 111, Route 908, Natrona Heights, PA 15065 | 724-295-2525</p>
  <div class ="hr"></div>
        <div class ="spacer40"></div>

		<!--footer class="site-footer" role="contentinfo"-->

			
		<!--/footer><!-- #colophon -->
	

	<?php wp_footer(); ?>
    </div><!-- #main -->
</body>
</html>