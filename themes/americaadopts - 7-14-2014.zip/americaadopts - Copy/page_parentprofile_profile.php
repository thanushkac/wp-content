<?php
$isSingleParent = get_post_meta($post->ID, 'isSingleParent', true);
$profileImage = get_post_meta($post->ID, 'profileImage', true);
$partner1FirstName = get_post_meta($post->ID, 'partner1FirstName', true);
$partner2FirstName = get_post_meta($post->ID, 'partner2FirstName', true);
$partner1Age = get_post_meta($post->ID, 'partner1Age', true);
$partner2Age = get_post_meta($post->ID, 'partner2Age', true);
$partner1Education = get_post_meta($post->ID, 'partner1Education', true);
$partner2Education = get_post_meta($post->ID, 'partner2Education', true);
$partner1Profession = get_post_meta($post->ID, 'partner1Profession', true);
$partner2Profession = get_post_meta($post->ID, 'partner2Profession', true);
$partner1Religion = get_post_meta($post->ID, 'partner1Religion', true);
$partner2Religion = get_post_meta($post->ID, 'partner2Religion', true);
$partner1Ethnicity = get_post_meta($post->ID, 'partner1Ethnicity', true);
$partner2Ethnicity = get_post_meta($post->ID, 'partner2Ethnicity', true);
$partner1AstrologicalSign = get_post_meta($post->ID, 'partner1AstrologicalSign', true);
$partner2AstrologicalSign = get_post_meta($post->ID, 'partner2AstrologicalSign', true);
$partner1Hobbies = get_post_meta($post->ID, 'partner1Hobbies', true);
$partner2Hobbies = get_post_meta($post->ID, 'partner2Hobbies', true);
$childAge = get_post_meta($post->ID, 'childAge', true);
$childGender = get_post_meta($post->ID, 'childGender', true);
$childEthnicity = get_post_meta($post->ID, 'childEthnicity', true);
$childEthnicity1 = get_post_meta($post->ID, 'childEthnicity1', true);
$childEthnicity2 = get_post_meta($post->ID, 'childEthnicity2', true);
$specialNeeds = get_post_meta($post->ID, 'specialNeeds', true);
$childAdoptionType = get_post_meta($post->ID, 'childAdoptionType', true);
$yearsTogether = get_post_meta($post->ID, 'yearsTogether', true);
$otherChildren = get_post_meta($post->ID, 'otherChildren', true);
$pets = get_post_meta($post->ID, 'pets', true);
$partner1Fav1 = get_post_meta($post->ID, 'partner1Fav1', true);
$partner1Fav2 = get_post_meta($post->ID, 'partner1Fav2', true);
$partner1Fav3 = get_post_meta($post->ID, 'partner1Fav3', true);
$partner1Fav4 = get_post_meta($post->ID, 'partner1Fav4', true);
$partner1Fav5 = get_post_meta($post->ID, 'partner1Fav5', true);
$partner1Fav6 = get_post_meta($post->ID, 'partner1Fav6', true);
$partner1Fav7 = get_post_meta($post->ID, 'partner1Fav7', true);
$partner1Fav8 = get_post_meta($post->ID, 'partner1Fav8', true);
$partner1Fav9 = get_post_meta($post->ID, 'partner1Fav9', true);
$partner1Fav10 = get_post_meta($post->ID, 'partner1Fav10', true);
$partner2Fav1 = get_post_meta($post->ID, 'partner2Fav1', true);
$partner2Fav2 = get_post_meta($post->ID, 'partner2Fav2', true);
$partner2Fav3 = get_post_meta($post->ID, 'partner2Fav3', true);
$partner2Fav4 = get_post_meta($post->ID, 'partner2Fav4', true);
$partner2Fav5 = get_post_meta($post->ID, 'partner2Fav5', true);
$partner2Fav6 = get_post_meta($post->ID, 'partner2Fav6', true);
$partner2Fav7 = get_post_meta($post->ID, 'partner2Fav7', true);
$partner2Fav8 = get_post_meta($post->ID, 'partner2Fav8', true);
$partner2Fav9 = get_post_meta($post->ID, 'partner2Fav9', true);
$partner2Fav10 = get_post_meta($post->ID, 'partner2Fav10', true);
$partner1FunFact1 = get_post_meta($post->ID, 'partner1FunFact1', true);
$partner2FunFact1 = get_post_meta($post->ID, 'partner2FunFact1', true);
$partner1FunFact2 = get_post_meta($post->ID, 'partner1FunFact2', true);
$partner2FunFact2 = get_post_meta($post->ID, 'partner2FunFact2', true);
$partner1FunFact3 = get_post_meta($post->ID, 'partner1FunFact3', true);
$partner2FunFact3 = get_post_meta($post->ID, 'partner2FunFact3', true);
$partner1FunFact4 = get_post_meta($post->ID, 'partner1FunFact4', true);
$partner2FunFact4 = get_post_meta($post->ID, 'partner2FunFact4', true);
$partner1FunFact5 = get_post_meta($post->ID, 'partner1FunFact5', true);
$partner2FunFact5 = get_post_meta($post->ID, 'partner2FunFact5', true);
$partner1FunFact6 = get_post_meta($post->ID, 'partner1FunFact6', true);
$partner2FunFact6 = get_post_meta($post->ID, 'partner2FunFact6', true);
$partner1FunFact7 = get_post_meta($post->ID, 'partner1FunFact7', true);
$partner2FunFact7 = get_post_meta($post->ID, 'partner2FunFact7', true);
$partner1FunFact8 = get_post_meta($post->ID, 'partner1FunFact8', true);
$partner2FunFact8 = get_post_meta($post->ID, 'partner2FunFact8', true);
$partner1FunFact9 = get_post_meta($post->ID, 'partner1FunFact9', true);
$partner2FunFact9 = get_post_meta($post->ID, 'partner2FunFact9', true);
$partner1FunFact10 = get_post_meta($post->ID, 'partner1FunFact10', true);
$partner2FunFact10 = get_post_meta($post->ID, 'partner2FunFact10', true);
$city = get_post_meta($post->ID, 'city', true);
$state = get_post_meta($post->ID, 'state', true);
$neighborhood = get_post_meta($post->ID, 'neighborhood', true);

if($childEthnicity1 != "" && $childEthnicity1 != "No preference") {
  $childEthnicity = $childEthnicity. ", " . $childEthnicity1;
}
if($childEthnicity2 != "" && $childEthnicity2 != "No preference") {
  $childEthnicity = $childEthnicity. ", " . $childEthnicity2;
}
?>

<div class="container">
<div class="row image-resized">
<img src="<?php echo $profileImage; ?>" alt="Our Personal Profile Image" title="Our Personal Profile Image"/>
</div>
</div>
<div class="row spacer"></div>
<div class="row spacer"></div>



<div class="container"> <!--page content container-->
<div class="row"><!--main row -->
<div class="col-md-8 parents">
<!--?php if ( function_exists( 'floating_social_bar' ) ) floating_social_bar( array( 'facebook' => true, 'twitter' => true, 'google' => true, 'pinterest' => true ) ); ?-->
<table class="table table table-condensed table-bordered">
 <thead>
 <tr>
 <th></th>
 <th class="bluetext"><?php echo $partner1FirstName; ?></th>
 <th class="bluetext"><?php echo $partner2FirstName; ?></th>
 </tr>
 </thead>
 <tbody>
 <?php if ($partner1Age != "" && $partner2Age != "") : ?>
 <tr>
 <td class="col-md-2 col-sm-2 col-xs-2">Age</td>
 <td class="col-md-5 col-sm-5 col-xs-5"><?php echo $partner1Age; ?></td>
 <td class="col-md-5 col-sm-5 col-xs-5"><?php echo $partner2Age; ?></td>
</tr>
<?php endif; ?>
<tr>

		<td>Education</td>
		<td><?php echo $partner1Education; ?></td>
		<td><?php echo $partner2Education; ?></td>
	</tr>
	<tr>
		<td>Profession</td>
		<td><?php echo $partner1Profession; ?></td>
		<td><?php echo $partner2Profession; ?></td>
	</tr>
	<tr>
		<td>Ethnicity</td>
		<td><?php echo $partner1Ethnicity; ?></td>
		<td><?php echo $partner2Ethnicity; ?></td>
	</tr>
	<tr>
		<td>Religion</td>
		<td><?php echo $partner1Religion; ?></td>
		<td><?php echo $partner2Religion; ?></td>
	</tr>
	<tr>
		<td>Astrological Sign</td>
		<td><?php echo $partner1AstrologicalSign; ?></td>
		<td><?php echo $partner2AstrologicalSign; ?></td>
	</tr>
	<tr>
		<td>Hobbies</td>
		<td><?php echo $partner1Hobbies; ?></td>
		<td><?php echo $partner2Hobbies; ?></td>
	</tr>

 </tbody>
</table>
<table class="table table-condensed table-bordered">
 <thead>
 <tr>
 <th class="tableitemheading"><?php if($isSingleParent == 'True') echo "My";  else echo "Our"; ?> Favorites</th>
 <th></th>
 <th></th>
 </tr>
 </thead>
 <tbody>
 <tr>
		<td class="col-md-2 col-sm-2 col-xs-2">Music</td>
		<td class="col-md-5 col-sm-5 col-xs-5"><?php echo $partner1Fav1; ?></td>
		<td class="col-md-5 col-sm-5 col-xs-5"><?php echo $partner2Fav1; ?></td>
	</tr>
	<tr>
		<td class="column1">Singer</td>
		<td class="column2"><?php echo $partner1Fav2; ?></td>
		<td class="column3"><?php echo $partner2Fav2; ?></td>
	</tr>
	<tr>
		<td class="column1">Song</td>
		<td class="column2"><?php echo $partner1Fav3; ?></td>
		<td class="column3"><?php echo $partner2Fav3; ?></td>
	</tr>
	<tr>
		<td class="column1">TV Show</td>
		<td class="column2"><?php echo $partner1Fav4; ?></td>
		<td class="column3"><?php echo $partner2Fav4; ?></td>
	</tr>
	<tr>
		<td class="column1">Movie</td>
		<td class="column2"><?php echo $partner1Fav5; ?></td>
		<td class="column3"><?php echo $partner2Fav5; ?></td>
	</tr>
	<tr>
		<td class="column1">Actor/Actress</td>
		<td class="column2"><?php echo $partner1Fav6; ?></td>
		<td class="column3"><?php echo $partner2Fav6; ?></td>
	</tr>
	<tr>
		<td class="column1">Animal</td>
		<td class="column2"><?php echo $partner1Fav7; ?></td>
		<td class="column3"><?php echo $partner2Fav7; ?></td>
	</tr>
	<tr>
		<td class="column1">Book</td>
		<td class="column2"><?php echo $partner1Fav8; ?></td>
		<td class="column3"><?php echo $partner2Fav8; ?></td>
	</tr>
	<tr>
		<td class="column1">Sport</td>
		<td class="column2"><?php echo $partner1Fav9; ?></td>
		<td class="column3"><?php echo $partner2Fav9; ?></td>
	</tr>
	<tr>
		<td class="column1">City</td>
		<td class="column2"><?php echo $partner1Fav10; ?></td>
		<td class="column3"><?php echo $partner2Fav10; ?></td>
	</tr>
 </tbody>
 </table>
 
 <table class="table table table-condensed table-bordered">
 <thead>
 <tr>
 <td colspan="2" class="tableitemheading">The child <?php if($isSingleParent == 'True') echo "I'd";  else echo "We'd"; ?> like to adopt</td>
  
 </tr>
 </thead>
 <tbody>
 <tr>
		<td class="col-md-2 col-sm-2 col-xs-2">Age</td>
		<td class="col-md-10 col-sm-10 col-xs-10"><?php echo $childAge; ?></td>
	</tr>
	<tr>
		<td class="column1">Sex</td>
		<td class="column2Long"><?php echo $childGender; ?></td>
	</tr>
	<tr>
		<td class="column1">Ethnicity</td>
		<td class="column2Long"><?php echo $childEthnicity; ?></td>
	</tr>
	<tr>
		<td class="column1">Special Needs</td>
		<td class="column2Long"><?php echo $specialNeeds; ?></td>
	</tr>
	<tr>
		<td class="column1">Type of Adoption</td>
		<td class="column2Long"><?php echo $childAdoptionType; ?></td>
	</tr>
 </tbody>
 </table>
 
 <div class="spacer"></div>
 
 
  <!--table class="table table-condensed parentprofiletable table-striped">
 <thead>
 <tr>
 <td colspan="2" class="tableitemheading"><!--?php if($isSingleParent == 'True') echo "My Life";  else echo "Our Life Together"; ?> </td>
  
 </tr>
 </thead>
 <tbody>
 <!--?php if ($isSingleParent == 'False') {?>
  <tr>
    <td class="column1">Years together</td>
    <td class="column2Long"><!--?php echo $yearsTogether; ?></td>
  </tr>
  <!--?php } ?>
	<tr>
		<td class="column1">Other Children</td>
		<td class="column2Long"><!--?php echo $otherChildren; ?></td>
	</tr>
	<tr>
		<td class="column1">Pets</td>
		<td class="column2Long"><!--?php echo $pets; ?></td>
	</tr>
 </tbody>
 </table-->
 
 </div><!-- end col8-->
  <div class="col-md-4"><!--sidebar -->
  <div class="sidebarparents">
 
  <div class="quickfacts row"><!--quickfacts-->
  <h4 class="text-center">QUICK FACTS</h4>
  <?php if ($isSingleParent == 'False') {?>
  <div><strong>Years together:</strong> <?php echo $yearsTogether; ?></div>
  <?php } ?>
  <div><strong>Where <?php if($isSingleParent == 'True') echo "I";  else echo "we" ;?> live:</strong>	<?php echo $city; ?>, <?php echo $state; ?></div>
			<div><strong><?php if($isSingleParent == 'True') echo "My";  else echo "Our"; ?> neighborhood:</strong> <?php echo $neighborhood; ?></div>
			<div><strong>Other children:</strong> <?php echo $otherChildren; ?></div>
			<div><strong>Pets:</strong> <?php echo $pets; ?></div>
  </div><!--quickfacts end-->
  <div class="quoteparents hidden-xs hidden-sm"><!--quoteparents-->
  <?php echo get_post_meta($post->ID, 'quoteLetterPage', true); ?>
  </div><!--quoteparents end-->
  </div><!--sidebarparents end-->
  
  </div><!--sidebar end -->
</div><!--main row end -->
</div><!--page content container end -->