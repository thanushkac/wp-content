<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?>

		</div><!-- #main -->

		<footer id="colophon" class="site-footer" role="contentinfo">

			<?php get_sidebar( 'footer' ); ?>

			<div class="footer text-center"><a href="http://www.canadaadopts.com/pregnant/">PREGNANT?</a> | <a href="http://www.canadaadopts.com/hoping-to-adopt/">HOPING TO ADOPT </a> | <a href="http://www.canadaadopts.com/adoption-profiles/">FIND A FAMILY</a> | <a
        href="http://www.canadaadopts.com/services/">SERVICES</a> | <a href="http://www.canadaadopts.com/resources/">RESOURCES</a> | <a href="http://www.canadaadopts.com/about-us/">ABOUT US</a></br>
    <small><a href="http://www.canadaadopts.com/us/terms-use/" class="orangetxt">Terms of Use </a>| <a class="orangetxt" href="http://www.canadaadopts.com/privacy-policy/">Privacy</a></small>
    </br>
    <small>Copyright © 2014. All rights reserved. America Adopts</small>
  </div>
		</footer><!-- #colophon -->
	</div><!-- #page -->
	<?php wp_footer(); ?>
</body>
</html>